﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardgameApp

{
    public class Card : IComparable<Card>, IEquatable<Card>
    {
        public int CardValue { get; set; }
        public int CardId { get; set; }
        public int gameValue { get; set; }
        public String Name { get; set; }



        public Card()
        {
            CardId = 0;
        }


        public int getValue()
        {
            return CardValue;
        }



        public int CompareTo(object obj)
        {
            if (obj == null)
                return 1;

            Card objAsCard = obj as Card;
            if (objAsCard == null)
                return 0;
            else
                return 1;
        }

        public int Id()
        {
            return CardId;
        }

        public String ReturnNameAsString()
        {
            return this.Name;
        }
        public override string ToString()
        {
            return "CardId:" + CardId + " CardValue:" + CardValue + " " + Name;
        }

        int IComparable<Card>.CompareTo(Card other)
        {


            // A null value means that this object is greater.
            if (other == null)

                return 1;

            else
                return this.CardId.CompareTo(other.CardId);

        }

        public bool Equals(Card other)
        {
            {
                if (other == null) return false;
                return (this.CardValue.Equals(other.CardValue));
            }
        }
    }
}
