﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardgameApp
{
    public class Deck
    {
        public List<Card> cards = new List<Card>();

        

        private List<Card> _cardList;
        private List<Card> _previousState;
        private int _decks;
        private int _numberOfCards;


        public Deck(int nbrOfDecks)
        {
            _decks = nbrOfDecks;
            _cardList = new List<Card>();
            _previousState = new List<Card>();
            _numberOfCards = 0;
        }








        /* Private method for adding hearts to Deck. Hearts has base value 100, so Ace has 101, "2 of hearts": 102 and so on.
         * addHearts() puts <Card> objects formated with "Heart Card values" into _cardList which is a generic List<T> 
        
        */
        private void addHearts()
        {

            _numberOfCards = 0;
            String hearts = "H";

            for (int k = 1; k <= 13; k++)
            {

                for (int i = 0; i < _decks; i++)
                {
                    var item = new Card();
                    item.CardValue = 100 + k;
                    item.CardId = _numberOfCards;
                
                    item.Name = k.ToString() + hearts;
                    _cardList.Add(item);
                    _numberOfCards++;
                }
            }
        }

        // Private method for adding Diamonds to Deck. Diamonds has base value 200.
        private void addDiamonds()
        {
            String diamonds = "D";
            for (int k = 1; k <= 13; k++)
            {
                for (int i = 0; i < _decks; i++)
                 {
                    var item = new Card();
                    item.CardValue = 200 + k;
                    item.CardId = _numberOfCards;
                    item.Name = k.ToString() + diamonds;
                    _cardList.Add(item);
                    _numberOfCards++;
                }
            }
        }

        // Private method for adding Clover to Deck. Clover has base value of 300 .
        private void addClover()
        {
            String clover = "C";

            for(int k = 1; k <= 13; k++)
            {
                for (int i = 0; i < _decks; i++)
                {
                    var item = new Card();
                    item.CardValue = 300 + k;
                    item.CardId = _numberOfCards;
                    item.Name = k.ToString() + clover;
                    _cardList.Add(item);
                    _numberOfCards++;

                }
            }
        }

        // Private method for adding Spades to Deck. Spade has base value of 400
        private void addSpades()
        {
            String spades = "S";
            
                for (int k = 1; k <= 13; k++)
                {
                    for (int i = 0; i < _decks; i++)
                    {
                        var item = new Card();
                        item.CardValue = 400 + k;
                        item.CardId = _numberOfCards;
                        item.Name = k.ToString() + spades;
                        _cardList.Add(item);
                        _numberOfCards++;
                    }
            }
        }
        public void createDeck()
        {
            addHearts();
            addDiamonds();
            addClover();
            addSpades();
        }

        /* Shuffles the Decks of cards in random order based on unique ID of the specific <Card> Object not CardValue as many Cards may have the same value.
         * Returns a new shuffled List<Card> replacing the old list.
         */

        public List<Card> shuffle()
        {
            var originalDeck = new List<Card>();
            var shuffledDeck = new List<Card>();
            var randomGen = new Random();
            int randomPosition = 0;
            Card nextItem;



            // copy the content of _cardList to originalDeck
            foreach (Card item in _cardList)
            {
                originalDeck.Add(item);
            }

            while (originalDeck.Count() > 0)
            {
                randomPosition = randomGen.Next(0, originalDeck.Count());
                nextItem = originalDeck[randomPosition];
                shuffledDeck.Add(nextItem);
                originalDeck.RemoveAt(randomPosition);
            }

            foreach (Card anItem in shuffledDeck)
            {
                Console.WriteLine(anItem.ToString());
            }
            Console.ReadLine();

            _cardList = shuffledDeck;

            return shuffledDeck;
        }
        // Extra shuffle method without return value only changing inner state to shuffled beacuse Unit Tests respond better
        public void voidShuffle()

        {
            var originalDeck = new List<Card>();
            var shuffledDeck = new List<Card>();
            var randomGen = new Random();
            int randomPosition = 0;
            Card nextItem;



            // copy the content of _cardList to originalDeck
            foreach (Card item in _cardList)
            {
                originalDeck.Add(item);
            }

            while (originalDeck.Count() > 0)
            {
                randomPosition = randomGen.Next(0, originalDeck.Count());
                nextItem = originalDeck[randomPosition];
                shuffledDeck.Add(nextItem);
                originalDeck.RemoveAt(randomPosition);
            }



            _cardList = shuffledDeck;


        }

        public List<Card> GetList()
        {
            return _cardList;
        }

        public int getNumberOfCard()
        {
            return _numberOfCards;
        }


        public Card pullCard()
        {
            Card card = new Card();
            if (_cardList.Count() > 0)
            {

                var id = _cardList[0].CardId;
                var value = _cardList[0].CardValue;
                var name = _cardList[0].Name;

                card.CardId = id;
                card.CardValue = value;
                card.Name = name;
                _cardList.RemoveAt(0);

                _numberOfCards = _cardList.Count();
                return card;
            }

            return card;


        }

        public List<Card> sortDeck()
        {
            _cardList.Sort();

            return _cardList;
        }

        public void setPreviousState()
        {

            foreach (Card item in _cardList)
            {
                _previousState.Add(item);

            }
        }

        public List<Card> getPreviousState()
        {
            return _previousState;
        }

        public void voidSort()
        {
            _cardList.Sort();

        }

        // **************** TEST HELPER METHODS *******************************************
        public bool Test_Decks_Are_Equaly_Sorted_Method(List<Card> sortedList, List<Card> otherList)

        {

            //sortedList = this.GetList();
            if (sortedList.Count() != otherList.Count())
            {
                return false;

            }

            int[] newarray = new int[sortedList.Count()];
            int[] otherarray = new int[otherList.Count()];

            for (int k = 0; k < sortedList.Count(); k++)
            {
                int theId = sortedList[k].Id();
                int theotherId = otherList[k].Id();
                

                if (theId != theotherId)
                    return false;


            }
            

            return true;

        }

        public double Test_Random_Shuffle(List<Card> deck1, List<Card> deck2)

        {

            var originalDeck = new List<Card>();
            var changed = 0;
            var unchanged = 0;
            double result;

            // loop over shuffled and orignal List to evaluate nbr of Changed/unchanged postions
            for (int k = 0; k < deck1.Count(); k++)
            {
                if (!deck1[k].Equals(deck2[k]))
                {
                    changed++;
                }
                else
                {
                    unchanged++;
                }
            }



            if (changed == 0)
                result = 0.0;
            else
                result = (double)unchanged / changed;

            return result;
        }

        public int Test_Random_Shuffled()
        {

            var originalDeck = getPreviousState();
            var changed = 0;
            var unchanged = 0;
            int result = 0;


            int[] arr = new int[_cardList.Count()];


            int i = 0;
            foreach (Card item in originalDeck)
            {
                arr[i] = item.Id();

                i++;
            }

            int k = 0;
            int id = 0;
            foreach (Card item in _cardList)
            {
                id = arr[k];
                if (item.Id() != id)
                {
                    changed++;
                }
                else
                {
                    unchanged++;
                }

                k++;

            }



            if (changed == 0)
            {
                result = 0;
            }
            else
            {
                result = changed;
            }

            return result;
        }



        public bool IsSorted()
        {
            int[] arr = new int[_cardList.Count()];

            int k = 0;

            foreach (Card item in _cardList)
            {
                arr[k] = item.Id();
                k++;
            }

            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i - 1] > arr[i])
                {
                    return false;
                }
            }
            return true;
        }








    }
}
