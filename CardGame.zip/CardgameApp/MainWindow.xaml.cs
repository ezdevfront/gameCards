﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CardgameApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Deck deckModell;
        public MainWindow()
        {
           InitializeComponent();

           deckModell = InitialaizeCardGame();
        }

        public Deck InitialaizeCardGame()
        {
            Deck CardDeck;
            CardDeck = new Deck(2);

            CardDeck.createDeck();
            return CardDeck;
        }

        public String GetPathString(Card pulledCard)
        {
            var cardOnDeck = pulledCard;
            var cardType = cardOnDeck.ReturnNameAsString();
            var pathString = @"/Images/cards/"+cardType+".png";
            return pathString;
        }
        // New Game
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            deckModell = null;
            String UriSource = @"/Images/cards/purple_back.png";
            CardWiew.Source = new BitmapImage(new Uri(UriSource, UriKind.Relative));
            deckModell = InitialaizeCardGame();
        }

        // Pull Card
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Card newCard = deckModell.pullCard();
            String source2 = GetPathString(newCard);
            CardWiew.Source = new BitmapImage(new Uri(source2, UriKind.Relative));
        }

        // Shuffle
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            deckModell.voidShuffle();
            String UriSource = @"/Images/cards/purple_back.png";
            CardWiew.Source = new BitmapImage(new Uri(UriSource, UriKind.Relative));
        }   

        // Sort
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            deckModell.sortDeck();
            String UriSource = @"/Images/cards/purple_back.png";
            CardWiew.Source = new BitmapImage(new Uri(UriSource, UriKind.Relative));
        }

        // Click to show backside
        private void CardWiew_MouseDown(object sender, MouseButtonEventArgs e)
        {
            String UriSource = @"/Images/cards/purple_back.png";
            CardWiew.Source = new BitmapImage(new Uri(UriSource, UriKind.Relative));

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            this.Close();
            e.Handled = true;
        }
    }
}
