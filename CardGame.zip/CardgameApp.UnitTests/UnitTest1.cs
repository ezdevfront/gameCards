﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CardgameApp.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_if_CardDeck_Is_Sorted()
        {
            // Arrange
            bool result = false;
            Deck cardDeck = new Deck(1);
            cardDeck.createDeck();

            //Act
            cardDeck.voidShuffle();
            cardDeck.voidSort();

            result = cardDeck.IsSorted();

            Assert.IsTrue(result);

        }

        [TestMethod]
        public void Test_if_CardDeck_Is_Shuffled_()
        {
            // Arrange

            Deck cardDeck = new Deck(1);
            cardDeck.createDeck();
            cardDeck.setPreviousState();
            int preresult = cardDeck.getNumberOfCard() / 2;
            int result = 0;
            bool expected = false;


            // Act
            cardDeck.voidShuffle();
            result = cardDeck.Test_Random_Shuffled();


            if (result > preresult)
                expected = true;
            else
                expected = false;





            // Assert
            Assert.IsTrue(expected);

        }

        [TestMethod]
        public void Test_if_Card_Is_Drawn()
        {
            // Arrange
            Boolean expected = false;
            int result = 0;
            Deck cardDeck = new Deck(1);
            Card pulledCard = null;
            cardDeck.createDeck();
            int LastnumberOfcards = cardDeck.getNumberOfCard();

            //Act
            pulledCard = cardDeck.pullCard();

            result = LastnumberOfcards - cardDeck.getNumberOfCard();

            if (result == 1)
                expected = true;
            else
                expected = false;

            // Assert

            Assert.IsTrue(expected);

        }










    }
}
